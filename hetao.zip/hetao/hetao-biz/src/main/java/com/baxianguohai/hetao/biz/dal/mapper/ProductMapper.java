package com.baxianguohai.hetao.biz.dal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baxianguohai.hetao.biz.dal.model.ProductDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品表
 * 
 * @author code-generator
 * @date 2019-12-02 17:44:43
 */
//@Mapper
public interface ProductMapper extends BaseMapper<ProductDO> {



}
