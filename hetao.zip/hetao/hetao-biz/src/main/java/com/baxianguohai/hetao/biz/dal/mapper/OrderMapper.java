package com.baxianguohai.hetao.biz.dal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baxianguohai.hetao.biz.dal.model.OrderDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单主表
 * 
 * @author code-generator
 * @date 2019-12-02 17:44:43
 */
//@Mapper
public interface OrderMapper extends BaseMapper<OrderDO> {



}
