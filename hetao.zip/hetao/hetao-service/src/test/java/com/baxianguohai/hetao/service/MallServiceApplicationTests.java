/*
package com.baxianguohai.hetaodamai.mall.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
*/
