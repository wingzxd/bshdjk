package com.baxianguohai.hetao.service.service;

/**
 * 订单商品表
 *
 * @author code-generator
 * @date 2019-12-02 17:44:43
 */
public interface OrderProductService {


}
