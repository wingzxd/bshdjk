package com.baixianguohai.hetao.core.manager;

/**
 * 用户表
 *
 * @author code-generator
 * @date 2019-12-02 17:44:43
 */
public interface UserManager {


}
